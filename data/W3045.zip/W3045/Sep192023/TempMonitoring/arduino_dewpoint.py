import serial
import time
import datetime
import matplotlib.pyplot as plt
from serial.tools import list_ports
#import busio
#import adafruit_mprls
#import board
import numpy as np

port = list(list_ports.comports())
for p in port:
    print(p.device)

location = input('Device path: ')
if location == '':
    location = '/dev/ttyACM0'
    location = 'COM4'
file_num = input('File name: ')
# location=
# # location="COM"
# baudrate=
# outtime=1
# ard = serial.Serial(location, baudrate)
# time.sleep(2) 
# print(ard.readline())
new = open('temp_monit_ambient_chamber_'+file_num+'.txt', 'w', 1)
new.write('time,roomtemp,chucktemp,chambertemp,humidity,dew_point\n')
print('>>>>Connecting to the arduino>>>>>>')
arduino = serial.Serial(port=location, baudrate=9600, timeout=.1)
#i2c = busio.I2C(board.SCL, board.SDA)
#mpr =adafruit_mprls.MPRLS(i2c, psi_min=0, psi_max=25)
print('>>>>Connection successful!>>>>>>')
print('>>>>Sending data....>>>>>>')
#arduino.write(45)
print('>>>>Sending data:Successful>>>>>>')
#arduino.write(bytes(b'a'))
print('>>>>Reading the data: Successful!>>>>>>')
print('>>>>Initiating plot>>>>>>')
starttime = datetime.datetime.now()
fig, ax = plt.subplots()
fig.subplots_adjust(right=0.75)

ax.scatter(0 , 0, color = 'blue', label = 'Readout Board Temp.', s=8)
ax.scatter(0 , 0, color = 'red', label = 'IV Box Temp.', s=8)
#ax.scatter(0 , 0, color = 'orange', label = 'Pressure', s=8)
# ax.scatter(0 , 0, color = 'purple', label = 'Dew Point', s=8)
ax.scatter(0 , 0, color = 'purple', label = 'Temp - Dew Point', s=8)
ax1 = ax.twinx()
ax.scatter(0 , 0, color = 'green', label = 'Relative Humidity', s=8)
ax.scatter(0, 0, color = 'white')
#ax2 = ax.twinx()
#ax2.spines.right.set_position(("axes", 1.2))

ax.set_xlabel('Duration [min]')
ax.set_ylabel('Temperature [$^0$C]')
ax1.set_ylabel('Relative Humidity [%]')
#ax2.set_ylabel('Pressure [atm]')
ax.legend()
ax.grid()
print('>>>>Initiating plot:Successful!>>>>>>')


try:
    while True:    
        
        #print('>>>>Reading....>>>>>>')
        data = arduino.readline()
        
        time.sleep(5)
        parameters = data.decode().split('*')
        if len(parameters) > 1 and len(parameters[1].split(','))>3:
            time_now = datetime.datetime.now()
            roomtemp = float(parameters[1].split(',')[0])
            chucktemp = float(parameters[1].split(',')[1])
            chambertemp = float(parameters[1].split(',')[2])
            humidity = float(parameters[1].split(',')[3])
            #dew point calculator
            a = 6.1121
            b = 18.678
            c = 257.14
            d = 234.5
            gamma_m  = np.log((humidity/100)*np.exp((b-chambertemp/d)*(chambertemp/(c+chambertemp))))
            dew_point = (c*gamma_m)/(b-gamma_m)
            #pressure = float(mpr.pressure)/1013.25
            diff = chambertemp - dew_point
            new.write(str(time_now)+','+str(roomtemp)+','+str(chucktemp)+','+str(chambertemp)+','+str(humidity)+'\n')
            mins = float((time_now - starttime).total_seconds())/60
            ax.axhline(10, color = 'black', linestyle = '-')
            ax.scatter(mins, chucktemp, s=5, color = 'blue')
            ax.scatter(mins, chambertemp, s=5, color = 'red')
            ax.scatter(mins, diff, s=5, color = 'purple')
            ax1.scatter(mins, humidity, s=5, color = 'green')
            #ax2.scatter(mins, pressure, s=5, color = 'orange')
            plt.pause(0.05)
except KeyboardInterrupt:
    plt.show()

arduino.close()
